-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 19-11-2021 a las 01:07:51
-- Versión del servidor: 10.4.20-MariaDB
-- Versión de PHP: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `pd3`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `artistas`
--

CREATE TABLE `artistas` (
  `id` int(8) NOT NULL,
  `nombre` varchar(30) COLLATE utf8mb4_spanish_ci NOT NULL,
  `apellido` varchar(30) COLLATE utf8mb4_spanish_ci NOT NULL,
  `bio` text COLLATE utf8mb4_spanish_ci NOT NULL,
  `foto` varchar(255) COLLATE utf8mb4_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `artistas`
--

INSERT INTO `artistas` (`id`, `nombre`, `apellido`, `bio`, `foto`) VALUES
(2, '<h5> Walter', 'Gropius</h5>', '<p><strong>Arquitecto y profesor alemán</strong>, fundador de la Bauhaus. Sus hipótesis más destacadas fueron <i>la economía expresiva \r\n                              y la adecuación a los medios productivos para todas las formas de diseño</i>, una especie de unificación entre el arte y la ingeniería. \r\n                              Conceptos que se ven reflejados en sus edificaciones. Nació en Berlín en 1883 y estudió arquitectura en las universidades de Múnich\r\n                               y Berlín-Carlottenburg.</p>\r\n                              <p>En colaboración con Adolph Meyer proyectó la fábrica Fagus en Alfeld (1910-1911) y el edificio de oficinas de la exposición del \r\n                              Werkbund en Colonia (1914), que le dieron a conocer en toda Europa. Después de la I Guerra Mundial dirigió dos escuelas de arte en \r\n                              Weimar, hasta que las transformó, en 1919, en <strong>la nueva Staatliches Bauhaus</strong>, donde <i>introdujo una pedagogía que aunaba el estudio del\r\n                               arte con el de la tecnología</i>. Cuando la escuela se trasladó a Dessau, Gropius proyectó los edificios que la acogerán, caracterizados\r\n                                por una exquisita simplicidad formal y por el empleo de grandes superficies de vidrio plano. Gropius abandonó su cargo como \r\n                                director de la Bauhaus en 1928 y continuó su carrera como arquitecto. </p>\r\n                              <p><b>Su oposición al partido nazi le obligó a abandonar \r\n                                Alemania en 1934</b>, y después de pasar varios años en Gran Bretaña emigró a Estados Unidos para dar clases en la Universidad \r\n                                de Harvard (donde introdujo muchas de las ideas desarrolladas en la Bauhaus).También construyó el edificio de la Panam (1963) \r\n                                en Nueva York, en colaboración con Pietro Beluschi. <strong>Gropius murió el 5 de julio de 1969 en Boston</strong>.</p>', 'img/profe1.png'),
(3, '<h5 >Hannes ', 'Meyer </h5>', '<p> <strong>Arquitecto suizo</strong>, nacido en 1889 en Basilea y fallecido en 1954 en Crocifisso di Savosa. \r\n                           Primero fue dibujante y a partir de 1909 comenzó a realizar edificaciones. \r\n                           Combinó sus estudios de arquitectura con sus primeros trabajos. Fue a clases de arquitectura \r\n                           en la universidad de Berlin, Technische Hochschule y a Kunstgewerbeschule.</p>\r\n                           <p> Sus primeros proyectos se basaban en un <strong>movimiento reformador agrario y urbano</strong> (edificios aún clásicos). \r\n                          Entre 1916 y 1918 se desempeñó como gerente de departamento en las obras de Krupp en Essen. En 1919 diseñó \r\n                          las viviendas en forma de panal de la urbanización Freidorf cerca de Basilea, y en 1926, adoptó el \r\n                          racionalismo del movimiento moderno.</p>\r\n                          <p>En 1927 fue <strong>profesor en la Bauhaus de Dessau</strong>, institución que dirigió entre 1928 y 1930 sucediendo \r\n                          al arquitecto alemán Walter Gropius. <i>Despedido por su actitud crítica hacia esta escuela</i>, partió hacia Moscú, \r\n                          donde dio clases de urbanismo hasta 1936; posteriormente trabajó en Suiza y, de 1939 a 1949, en México \r\n                          (dio clases en Escuela Superior de Ingeniería y Arquitectura (ESIA)). Sus planes urbanísticos no fueron\r\n                           aceptados nunca y pocos de sus proyectos arquitectónicos fueron llevados a cabo.</p>\r\n                           <p>La obra más famosa es <strong>el palacio de las Naciones de Ginebra (1926-1927) </strong>y construyó <strong>la Bundesschule des \r\n                          Allgemeinen Deutschen Gewerkschaftsbundes </strong>.</p>\r\n                          <p>Casado en 1917 con <i>Luise Bianca Nathalie Herkert</i>, tuvo dos hijas. Divorcio en 1936, al año siguiente se \r\n                          casó <i>Lena Bergner</i>, tuvo dos hijos. De sus relaciones con su secretaria <i>Margaret Mengel</i>, tuvo un hijo. \r\n                        <strong>Hannes Meyer falleció en 1954 en Suiza</strong>.\r\n                        </p>', 'img/profe2.png'),
(5, '<h5 >Ludwig', 'Mies van der Rohe</h5>', '<p><strong>Arquitecto alemán</strong>. Su primer oficio fue de cantero, luego se mudo a Berlín donde trabajó  \r\n                              en el estudio de <i>Bruno Paul</i> y, de 1908 a 1911, en el de <i>Peter Behrens</i>. Orientado hacia la \r\n                              arquitectura neoclásica pero, después de un viaje  a los Países Bajos en 1912, sus intereses cambiaron.</p>\r\n                              <p>Tras la Primera Guerra Mundial, se adhirió a <i>diversos movimientos de vanguardia</i> \r\n                              (Novembergruppe, De Stijl) y <strong>empezó a realizar proyectos revolucionarios</strong>, ej: un edificio \r\n                              de oficinas de la Friedrichstrasse de Berlín. Publico la revista G, en 1926 llevó a cabo \r\n                              la casa Wolf en Guben, la casa Hermann Lange en Krefeld, el monumento a Karl Liebknecht y Rosa Luxemburgo.\r\n                              Convertido en un <strong>arquitecto de prestigio</strong>, empezó a <i>recibir encargos</i> como por ejemplo:<i> un complejo experimental \r\n                              de viviendas para la Exposición de Stuttgart de 1927 (el Weissenhof Siedlung)</i> y <i>el pabellón de \r\n                              Alemania para la Exposición Internacional de Barcelona</i>.</p>\r\n                            <p>Suya es la famosa máxima: <strong>“menos es más”</strong>. Van der Rohe fue el tercer director de la Bauhaus, en \r\n                              el momento más complicado de la escuela (de 1930 a 1933). Se esforzó por mantener la Bauhaus al \r\n                            <i>margen de la política</i>. Sin embargo, el partido nazi acabó cerrando el centro en 1933.</p> \r\n                            <p><strong>Obligado a emigrar a Estados Unidos</strong>, nombrado director de la facultad de arquitectura del Illinois\r\n                               Technology Institute de Chicago (1938), genero fama por todo Estados Unidos.<i>Trabajó fundamentalmente \r\n                               en la capital de Illinois</i>.\r\n                              1958-1959 Seagram Building de Nueva York y la Neue Nationalgalerie de Berlín (1962-1968). </p>\r\n', 'img/profe3.png'),
(7, '<h5 >Herbert', 'Bayer</h5>', '<p><strong>Diseñador gráfico y pintor austríaco</strong>. 1919 - 1920 fue aprendiz en el estudio del diseñador \r\n                                Georg Schmidtthammer, en Linz, donde realizó sus <i>primeros trabajos tipográficos</i>. En 1921 \r\n                                trabajó en el taller del diseñador Emanuel Margol en Darmstald.</p>\r\n                              <p><strong>Estudió en la Bauhaus</strong> entre 1921-1923 y de 1924-1925. Asistió al taller de pintura mural \r\n                                con Schlemmer y Kandinsky. <i>Profesor en Bauhaus durante 1925 - 1928</i>. Director del  taller \r\n                                de impresión y publicidad, taller de tipografía y diseño publicitario. Diseños  impresos \r\n                                en la escuela. <i>Fue director de la Bauhaus de 1928 - 1930</i>. En 1928 dirigió la agencia publicitaria \r\n                                Studio Dorland.</p>\r\n                              <p>Fue el diseñador de publicidad <strong>más innovador</strong> de la Bauhaus, <i>su trabajo se destaca por la temprana \r\n                                introducción de la fotografía en los años 20</i>. En los Estados Unidos pudo ampliar su actividad al \r\n                                diseño del medio ambiente.</p>\r\n                              <p> <strong>Se dedicó a la pintura y la fotografía</strong>. <i>Emigró a EE.UU. en 1938</i>, mismo año que organiza la exposición \r\n                                y catálogo Bauhaus 1919-1918 en el Museum of Modern Art. Trabajó en Nueva York como diseñador gráfico. \r\n                                En 1946 realizó diseños en el Centro cultural Aspen/Colorado, con trabajos de pintura, diseño gráfico, \r\n                                arquitectura y ordenamiento paisajístico.</p>\r\n                              <p>De 1946 - 1956 fue consejero artístico de la Container Corporaton of America y desde 1966 de la Atlantic \r\n                                Richfield Company. En 1968 realizó una exposición y catálogo <i>“50 años Bauhaus”</i> en Stuttgart. En 1975 se \r\n                                trasladó a Montecito, California. <strong>Murió en Santa Bárbara</strong>.</p>\r\n                                 ', 'img/profe5.png'),
(9, '<h5>Láslo', 'Moholy-Nagy </h5>', '<p> <strong> Artista húngaro</strong>. Estudió derecho y se unió al círculo poético de Endre Ady. \r\n                            Quedo <i>herido en la Primera Guerra Mundial</i> y, en el proceso de  su recuperación, \r\n                            realizó los primeros dibujos de escenas bélicas. En 1918 decidió <i>dedicarse por completo al arte</i>.</p>\r\n                          <p> Se trasladó a Berlín, y entre 1923 y 1929 fue el <strong>profesor del taller de metales de la Bauhaus</strong>,\r\n                              así como director de una colección de libros editada por la institución, llamados <i>“los Bauhausbücher”</i>. </p>\r\n                            <p>Desarrolló un <strong>arte no figurativo </strong>y construyó sus obras a partir de elementos puramente \r\n                              visuales: <i>color, textura, luz y equilibrio de las formas</i>. Desarrolló proyectos en otros campos, \r\n                              entre ellos escenografías y vestuarios teatrales y diseño de exposiciones. </p>\r\n                            <p>En <strong>1935 se fue a Londres</strong>, \r\n                              luego <i>se escapó de los Nazis</i>. En <i>1937 fue director en Chicago de la New \r\n                              Bauhaus </i>(más tarde School of Design), basada en el modelo de la escuela alemana y en la que continuaría \r\n                              su importante labor pedagógica.</p>', 'img/profe6.png'),
(11, '<h5>Wassily ', ' Kandinsky</h5>', '<p>Pintor de origen ruso, <strong>arte abstracto</strong>. A los treinta años, Kandinsky abandonó la docencia y \r\n                              fue a estudiar pintura a Munich. <i>Su interés por el color se ve desde el comienzo de su carrera</i>, \r\n                              en sus primeras pinturas hay influencia del postimpresionismo, el fauvismo y el Jugendstil alemán.</p>\r\n                            <p>1902 - 1907 Kandinsky realizó viajes a Francia, Países Bajos, Túnez, Italia y Rusia. Se instaló en\r\n                               Murnau, donde pintó paisajes alpinos entre los años 1908 y 1910. Se dio cuenta de que la representación\r\n                                del objeto en sus pinturas era perjudicial y que <strong>la belleza estaba en la riqueza cromática y \r\n                                la simplificación formal</strong>. 1910, <i>definitivo la abstracción</i>.</p>\r\n                              <p>1910 - 1914 Kandinsky pintó en <strong>tres categorías</strong>: <i>las impresiones</i>, inspiradas en la naturaleza;<i> las \r\n                              improvisaciones</i>, emociones interiores; y <i>las composiciones</i>, que aunaban lo intuitivo con el más \r\n                              exigente rigor compositivo.</p>\r\n                            <p>Primera Guerra Mundial, Kandinsky volvió a Moscú; allí trabajo en el marco del Departamento de Bellas\r\n                               Artes del Comisariado Popular de la Educación. En 1917 se casó con Nina Andreievsky, y cuatro años más\r\n                                tarde se trasladó con ella a Alemania para <strong>incorporarse a la Bauhaus</strong> en la primera etapa de Weimar, \r\n                                como profesor hasta poco antes de su disolución. <i>Escribió manifiestos y publicó el libro Punto y \r\n                                línea sobre el plano</i>. Según él, cada forma y cada color representaban diferentes emociones o \r\n                                conceptos: <i>el círculo</i> era la armonía, la espiritualidad; <i>el triángulo</i> representa agresividad y \r\n                              <i>el cuadrado</i>, paz y calma. <strong>Clausurada la Bauhaus, el pintor se instaló en Francia.</strong></p>', 'img/profe4.png');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(8) NOT NULL,
  `nombre` varchar(90) COLLATE utf8mb4_spanish_ci NOT NULL,
  `email` varchar(155) COLLATE utf8mb4_spanish_ci NOT NULL,
  `usuario` varchar(50) COLLATE utf8mb4_spanish_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `email`, `usuario`, `password`) VALUES
(2, 'guada', 'guada@mail.com', 'guadalu', '202cb962ac59075b964b07152d234b70'),
(7, 'Guadalupe Barreiro', 'guada.barreiro.marin@gmail.com', 'guadi', 'ff24201db52f84fda2e848d09125c9aa'),
(8, 'maría sol', 'maria@sol', 'maria', '202cb962ac59075b964b07152d234b70'),
(9, 'Nicole', 'nico@nicole.com', 'nicole', 'fc63f87c08d505264caba37514cd0cfd'),
(10, 'mmm', 'guada.barreiro.marin@gmail.com', 'gbarre8', 'b3cd915d758008bd19d0f2428fbb354a'),
(11, 'Joaquin Barreiro', 'guada.barreiro.marin@gmail.com', 'Joaco', '202cb962ac59075b964b07152d234b70'),
(12, 'Cata Alvarez', 'guada.barreiro.marin@gmail.com', 'Cata', '202cb962ac59075b964b07152d234b70');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `artistas`
--
ALTER TABLE `artistas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `artistas`
--
ALTER TABLE `artistas`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
